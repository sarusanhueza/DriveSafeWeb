export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyCkjw9-oakbr8_1rfLQIFx8Ja4unjCN7bo",
    authDomain: "drivesafe-ff1b0.firebaseapp.com",
    projectId: "drivesafe-ff1b0",
    storageBucket: "drivesafe-ff1b0.appspot.com",
    messagingSenderId: "669426415695",
    appId: "1:669426415695:web:5768968390991ea4f3923a",
    measurementId: "G-8KF1EK6RSW"
  }
};

