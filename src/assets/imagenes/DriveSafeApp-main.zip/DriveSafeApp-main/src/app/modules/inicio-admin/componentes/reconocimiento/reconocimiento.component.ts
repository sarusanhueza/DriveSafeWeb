import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reconocimiento',
  templateUrl: './reconocimiento.component.html',
  styleUrls: ['./reconocimiento.component.scss'],
})
export class ReconocimientoComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
