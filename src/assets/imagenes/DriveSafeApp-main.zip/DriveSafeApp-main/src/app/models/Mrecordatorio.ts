export interface Recordatorio{
    uid: string | any;
    titulo: string;
    fecha: string;
    hora: string;
    nombreEvento: string;
    
}