

export interface Gastos{
    uid: string | any;
    titulo: string;
    fecha: string;
    nombreArticulo: string;
    precio: string;
  }