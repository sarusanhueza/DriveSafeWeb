export interface Viaje{
    uid: string | any;
    titulo: string;
    fecha: string;
    nombreEvento: string;
    lugarSalida:string;
    lugarDestino: string;
    
}