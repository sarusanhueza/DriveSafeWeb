export interface Vehiculo { //creamos interaz del vehiculo 
    uidVehiculo: string | any; // id proveniente del usuario
    nombre: string; // -> nombre del auto
    patente: string; // -> patente
    marca: string; // -> marca  
    combustible: string; //-->tipo de combustible
}

