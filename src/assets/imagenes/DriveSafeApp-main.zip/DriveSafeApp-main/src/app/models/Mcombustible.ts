export interface Combustible{
  uid: string | any;
  titulo: string;
  fecha: string;
  litros: string;
  tipo: string;
  gasto: string;
}
