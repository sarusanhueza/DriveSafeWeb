export interface Usuario {
    uid: string | any; // id para autentificación de Firebase
    uidVehiculo: string | any;
    email: string;
    nombre: string;
    fecha: string;
    contrasena: string;
    administrador: boolean;
}
